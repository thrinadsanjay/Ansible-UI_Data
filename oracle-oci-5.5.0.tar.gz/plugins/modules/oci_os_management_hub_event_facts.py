#!/usr/bin/python
# Copyright (c) 2020, 2025 Oracle and/or its affiliates.
# This software is made available to you under the terms of the GPL 3.0 license or the Apache 2.0 license.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
# Apache License v2.0
# See LICENSE.TXT for details.
# GENERATED FILE - DO NOT EDIT - MANUAL CHANGES WILL BE OVERWRITTEN


from __future__ import absolute_import, division, print_function

__metaclass__ = type

ANSIBLE_METADATA = {
    "metadata_version": "1.1",
    "status": ["preview"],
    "supported_by": "community",
}

DOCUMENTATION = """
---
module: oci_os_management_hub_event_facts
description: >-
    Due to size constraints we have not included the documentation in the module. Please check L(here,
    https://docs.oracle.com/en-us/iaas/tools/oci-ansible-collection/latest/collections/oracle/oci/oci_os_management_hub_event_facts_module.html)
    for the module documentation.
author: Oracle (@oracle)
"""


from ansible_collections.oracle.oci.plugins.module_utils import oci_common_utils
from ansible_collections.oracle.oci.plugins.module_utils.oci_resource_utils import (
    OCIResourceFactsHelperBase,
    get_custom_class,
    OCIAnsibleModule,
)

try:
    from oci.os_management_hub import EventClient

    HAS_OCI_PY_SDK = True
except ImportError:
    HAS_OCI_PY_SDK = False


class OsManagementHubEventFactsHelperGen(OCIResourceFactsHelperBase):
    """Supported operations: get, list"""

    def get_required_params_for_get(self):
        return [
            "event_id",
        ]

    def get_required_params_for_list(self):
        return []

    def get_resource(self):
        return oci_common_utils.call_with_backoff(
            self.client.get_event, event_id=self.module.params.get("event_id"),
        )

    def list_resources(self):
        optional_list_method_params = [
            "event_summary",
            "event_summary_contains",
            "event_fingerprint",
            "compartment_id",
            "lifecycle_state",
            "resource_id",
            "type",
            "time_created_less_than",
            "time_created_greater_than_or_equal_to",
            "sort_order",
            "sort_by",
            "is_managed_by_autonomous_linux",
        ]
        optional_kwargs = dict(
            (param, self.module.params[param])
            for param in optional_list_method_params
            if self.module.params.get(param) is not None
        )
        return oci_common_utils.list_all_resources(
            self.client.list_events, **optional_kwargs
        )


OsManagementHubEventFactsHelperCustom = get_custom_class(
    "OsManagementHubEventFactsHelperCustom"
)


class ResourceFactsHelper(
    OsManagementHubEventFactsHelperCustom, OsManagementHubEventFactsHelperGen
):
    pass


def main():
    module_args = oci_common_utils.get_common_arg_spec()
    module_args.update(
        dict(
            event_id=dict(aliases=["id"], type="str"),
            event_summary=dict(type="str"),
            event_summary_contains=dict(type="str"),
            event_fingerprint=dict(type="str"),
            compartment_id=dict(type="str"),
            lifecycle_state=dict(
                type="str",
                choices=[
                    "CREATING",
                    "UPDATING",
                    "ACTIVE",
                    "DELETING",
                    "DELETED",
                    "FAILED",
                ],
            ),
            resource_id=dict(type="str"),
            type=dict(
                type="list",
                elements="str",
                choices=[
                    "KERNEL_OOPS",
                    "KERNEL_CRASH",
                    "EXPLOIT_ATTEMPT",
                    "SOFTWARE_UPDATE",
                    "KSPLICE_UPDATE",
                    "SOFTWARE_SOURCE",
                    "AGENT",
                    "MANAGEMENT_STATION",
                ],
            ),
            time_created_less_than=dict(type="str"),
            time_created_greater_than_or_equal_to=dict(type="str"),
            sort_order=dict(type="str", choices=["ASC", "DESC"]),
            sort_by=dict(
                type="str",
                choices=[
                    "timeCreated",
                    "timeOccurredAt",
                    "timeUpdated",
                    "eventSummary",
                ],
            ),
            is_managed_by_autonomous_linux=dict(type="bool"),
        )
    )

    module = OCIAnsibleModule(argument_spec=module_args)

    if not HAS_OCI_PY_SDK:
        module.fail_json(msg="oci python sdk required for this module.")

    resource_facts_helper = ResourceFactsHelper(
        module=module,
        resource_type="event",
        service_client_class=EventClient,
        namespace="os_management_hub",
    )

    result = []

    if resource_facts_helper.is_get():
        result = [resource_facts_helper.get()]
    elif resource_facts_helper.is_list():
        result = resource_facts_helper.list()
    else:
        resource_facts_helper.fail()

    module.exit_json(events=result)


if __name__ == "__main__":
    main()
